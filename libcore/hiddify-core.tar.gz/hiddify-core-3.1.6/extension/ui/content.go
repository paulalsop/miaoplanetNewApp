package ui

// // ContentField represents a label with additional properties.
// type ContentField struct {
// 	GenericField
// 	Lines            int  `json:"lines,omitempty"`
// 	VerticalScroll   bool `json:"verticalScroll,omitempty"`
// 	HorizontalScroll bool `json:"horizontalScroll,omitempty"`
// 	Monospace        bool `json:"monospace,omitempty"`
// }

// // NewContentField creates a new ContentField.
// func NewContentField(key, label string, lines int, monospace, horizontalScroll, verticalScroll bool) ContentField {
// 	return ContentField{
// 		GenericField: GenericField{
// 			Key:   key,
// 			Type:  "Content",
// 			Label: label,
// 		},
// 		Lines:            lines,
// 		VerticalScroll:   verticalScroll,
// 		HorizontalScroll: horizontalScroll,
// 		Monospace:        monospace,
// 	}
// }
