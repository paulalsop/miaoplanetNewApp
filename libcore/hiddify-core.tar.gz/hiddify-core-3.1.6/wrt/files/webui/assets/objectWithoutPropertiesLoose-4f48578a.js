function a(r,o){if(r==null)return{};var n={},i=Object.keys(r),e,t;for(t=0;t<i.length;t++)e=i[t],!(o.indexOf(e)>=0)&&(n[e]=r[e]);return n}export{a as _};
